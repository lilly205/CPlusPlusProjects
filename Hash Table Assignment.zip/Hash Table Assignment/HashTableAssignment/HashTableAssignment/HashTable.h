#pragma once

#include <vector>
#include <string>
#include <cstdlib>

using namespace std;

template <class T, class K> class HashTable
{
public:
	struct Data
	{
		T value;
		K key;
		Data(T v, K k)
		{
			value = v;
			key = k;
		}
	};

	vector<vector<Data>> table;
	int size;//this would be m in the book.

	HashTable(int capacity = 1000)//Constructor
	{
		size = capacity;
		for (int i = 0; i < size; i++)
			table.push_back(vector<Data>());
	}


	T Search(K key)
	{
		int hash = Hash(key);
		int index = 0;
		while (index < (int)table[hash].size() - 1 && table[hash][index].key != key)
			index++;
		return table[hash][index].value;
	}


	T &operator[](T& key)
	{
		return Search(key);
	}

	void Insert(K key, T value)
	{
		table[Hash(key)].push_back(Data(value, key));
	}

	void Delete(K key)
	{
		int hash = Hash(key);
		int index = 0;
		while (index < table[hash].size() - 1 && table[hash][index].key != key)
			index++;
		table[hash].erase(table[hash].begin() + index);
	}

	int Hash(K key)
	{
		//Division Method
		return key % size;


		//Multiplication Method
		double k = key * (sqrt(5.0) - 1);//A in the book.
		return (int)(size * (k - (int)k));//Extract the fractional portion of k and multiply by size
	}

	int NumEmptyChains()
	{
		int numEmpty = 0;
		for (int i = 0; i < size; i++)
			numEmpty += table[i].size() ? 0 : 1;
		return numEmpty;
	}
};

template<class T> class HashTable<T, string>
{

public:
	struct Data
	{
		T value;
		string key;
		Data(T v, string k)
		{
			value = v;
			key = k;
		}
	};

	vector<vector<Data>> table;
	int size;//this would be m in the book.

	HashTable(int capacity = 1000)//Constructor
	{
		size = capacity;
		for (int i = 0; i < size; i++)
			table.push_back(vector<Data>());
	}


	T Search(string key)
	{
		int hash = Hash(key);
		int index = 0;
		while (index < (int)table[hash].size() - 1 && table[hash][index].key != key)
			index++;
		return table[hash][index].value;
	}


	T &operator[](string key)
	{
		int hash = Hash(key);
		int index = 0;
		while (index < (int)table[hash].size() - 1 && table[hash][index].key != key)
			index++;
		return table[hash][index].value;
	}

	void Insert(string key, T value)
	{
		table[Hash(key)].push_back(Data(value, key));
	}

	void Delete(string key)
	{
		int hash = Hash(key);
		int index = 0;
		while (index < table[hash].size() - 1 && table[hash][index].key != key)
			index++;
		table[hash].erase(table[hash].begin() + index);
	}

	int Hash(string key)
	{

		int hash = 1;
		for (int i = 0; i < key.length(); i++)
		{
			hash = (key[i] + hash*31) % size;
		}
		return hash;
	}


	int NumEmptyChains()
	{
		int numEmpty = 0;
		for (int i = 0; i < size; i++)
			numEmpty += table[i].size() ? 0 : 1;
		return numEmpty;
	}
};