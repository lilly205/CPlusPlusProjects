#include <iostream>
#include <string>
#include <random>
#include <time.h> 

#include "HashTable.h" 

using namespace std;

class ModelAsset//mimicing a 3D model in a game
{
public:
	string name;
	int vertices;
	ModelAsset()//Default Constructor (has no parameters)
	{
		name = "";
		vertices = 0;
	}
	ModelAsset(string n, int v)
	{
		name = n;
		vertices = v;
	}
};

int main()
{
	//Seed the random number generator so they are different each time
	srand((unsigned int)time(0)); 

	//Declare our hash table
	HashTable<ModelAsset, string> hashTable(100);
	
	//Insert some dummy data.
	for (int i = 0; i < 100; i++)
	{
		string tempKey = "";
		for (int j = 0; j < 5; j++)
			tempKey += (char)(rand() % 25 + 97);
	
		ModelAsset tempData(tempKey, rand() % 10000 + 100);
	
		//Put a breakpoint on this line and hit F5 or the Local Windows Debugger 'Play' button above to see what the tempKey's and tempData's look like
		hashTable.Insert(tempKey, tempData);		
	}
	
	//Insert some specific data
	hashTable.Insert("PlayerModel", ModelAsset("CharacterModel", 3000));
	hashTable.Insert("EnemyModel", ModelAsset("EnemyModel", 4000));
	hashTable.Insert("MonsterModel", ModelAsset("MonsterModel", 6000));
		
	//Demonstrate our hash table's functionality
	ModelAsset enemyModel = hashTable["EnemyModel"];

	cout << "Model name: " << enemyModel.name << " Vertices: " << enemyModel.vertices << endl;
	
	cout << "Empty hash table chains: " << hashTable.NumEmptyChains() << " out of " << hashTable.size << endl;
	
	cout << endl;

	return 0;
}