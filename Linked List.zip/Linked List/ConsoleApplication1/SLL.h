#pragma once

//A Singly-Linked List
template<class T>
class SLList
{
private:
	struct Node
	{
		T data;
		Node* next;


		Node(T val)
			: data(val),
			next(nullptr)
		{

		}
	};

	Node* head;
	Node* tail;

	int size = 0;

public:
	SLList()
		: head(nullptr),
		tail(nullptr)
	{

	}

	void Push_Front(T data)
	{
		if (size == 0)
		{
			head = new Node(data);
			tail = head;
		}
		else
		{
			Node* temp = head;
			head = new Node(data);
			head->next = temp;
		}
		size++;
	}

	void Push_Back(T data)//O(n) - linear complexity. 1n + 4 -> n
	{
		if (size == 0)
		{
			head = new Node(data);
			tail = head;
		}
		else
		{
			Node* temp = tail;
			temp->next = new Node(data);
			tail = temp->next;
		}
		size++;
	}

	void Insert(int index, T data)
	{
		Node* temp = head;
		for (int i = 0; i < index - 1 && temp->next != nullptr; i++)
			temp = temp->next;//Find the node BEFORE the spot we want to insert
		Node* temp2 = temp->next;//Find the node it points to and store its address temporarily
		temp->next = new Node(data);//insert the new node
		temp->next->next = temp2;//Reattach the rest of the list onto the new node
		size++;
	}

	void Remove(int index)
	{
		Node* temp = head, *temp2;
		for (int i = 0; i < index && temp->next != nullptr; i++)
		{
			temp2 = temp;//Keep track of the current node
			temp = temp->next;//Find the node we want to remove
		}
		temp2->next = temp->next;//Set the current node to point to the node AFTER the one we will remove
		delete temp;//Remove the node at the provided index
		size--;
	}

	T GetElement(int index) const//O(n). For a vector it would be O(1)
	{
		Node* temp = head;
		for (int i = 0; i < index && temp->next != nullptr; i++)
			temp = temp->next;
		return temp->data;
	}

	T operator[](int index) const//Overloaded operator so we can treat our lists like arrays with [] notation
	{
		return GetElement(index);
	}

	int Size() const
	{
		return size;
	}

	void DisplayList() const
	{
		Node* temp = head;
		while (temp != nullptr)
		{
			cout << temp->data << ", ";
			temp = temp->next;
		}
	}

	~SLList()
	{
		Node* temp = head;
		while (temp != nullptr)
		{
			head = head->next;
			delete temp;
			temp = head;
		}
	}
};