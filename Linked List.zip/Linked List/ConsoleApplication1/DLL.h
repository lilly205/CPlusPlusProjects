#pragma once

//A Singly-Linked List
template<class T>
class DLList
{
private:
	struct Node
	{
		T data;
		Node* next;
		Node* prev;


		Node(T val)
			: data(val),
			next(nullptr),
			prev(nullptr)
		{

		}
	};

	Node* head;
	Node* tail;

	int size = 0;

public:
	DLList()
		: head(nullptr),
		tail(nullptr)
	{

	}

	void Push_Front(T data)
	{
		if (size == 0)
		{
			head = new Node(data);
			tail = head;
		}
		else
		{
			Node* temp = head;
			head = new Node(data);
			head->next = temp;
			temp->prev = head;
			
		}
		size++;
	}

	void Push_Back(T data)//O(n) - linear complexity. 1n + 4 -> n
	{
		if (size == 0)
		{
			head = new Node(data);
			tail = head;
		}
		else
		{
			Node* temp = tail;
			temp->next = new Node(data);
			temp->next->prev = tail;
			tail = temp->next;
		}
		size++;
	}

	void Insert(int index, T data)
	{
		Node* temp = head;
		for (int i = 0; i < index && temp->next != nullptr; i++)
			temp = temp->next;//Find the node BEFORE the spot we want to insert

		temp->prev->next = new Node(data); 
		temp->prev->next->prev = temp->prev; //implies there is a previous node. Inserting at beginning wont work
		temp->prev->next->next = temp;
		temp->prev = temp->prev->next;

		size++;
	}

	void Remove(int index)
	{
		Node* temp = head;
		for (int i = 0; i < index && temp->next != nullptr; i++)
		{

			temp = temp->next;//Find the node we want to remove
		}
		temp->prev->next = temp->next;
		temp->next->prev = temp->prev;
		delete temp;//Remove the node at the provided index
		size--;
	}

	void Reverse()
	{
		Node* newHead = head;
		Node* temp = head->next;

		while (newHead->next != nullptr) //reverses next/prev with each other until last element (because before the change the last index's next is null)
		{
			newHead->next = newHead->prev;
			newHead->prev = temp;

			newHead = temp;
			temp = temp->next;
		}

		// reverses the last element's next/prev
		temp = newHead->next;
		newHead->next = newHead->prev;
		newHead->prev = temp;

		// the tail is now the head and vice versa
		temp = head;
		head = tail;
		tail = temp;
	}

	T GetElement(int index) const//O(n). For a vector it would be O(1)
	{
		Node* temp = head;
		for (int i = 0; i < index && temp->next != nullptr; i++)
			temp = temp->next;
		return temp->data;
	}

	T operator[](int index) const//Overloaded operator so we can treat our lists like arrays with [] notation
	{
		return GetElement(index);
	}

	int Size() const
	{
		return size;
	}

	void DisplayList() const
	{
		Node* temp = head;
		while (temp != nullptr)
		{
			cout << temp->data << ", ";
			temp = temp->next;
		}
	}

	~DLList()
	{
		Node* temp = head;
		while (temp != nullptr)
		{
			head = head->next;
			delete temp;
			temp = head;
		}
	}
};