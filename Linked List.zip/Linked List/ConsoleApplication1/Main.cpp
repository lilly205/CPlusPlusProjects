#include <iostream>
#include "SLL.h"
#include "DLL.h"

using namespace std;

int main()
{
	DLList<int> list;
	
	for (int i = 0; i < 10; i++)
	{
		list.Push_Back(i);
	}
	cout << "Before Reverse: ";
	list.DisplayList();
	cout << endl;

	list.Reverse();

	cout << "After Reverse: ";
	list.DisplayList();
	cout << endl;

	return 0;
}