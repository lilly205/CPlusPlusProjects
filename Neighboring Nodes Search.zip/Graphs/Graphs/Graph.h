#pragma once

#include<vector>
#include<stack>
#include<queue>
using namespace std;

/*Vocab
Graph is a collection of vertices and edges
A directional graph - you can only go one way across an edge
Undirectional graph is the opposite
Mixed Graph - some you can go one way, some both ways
Cycle - edges eventually come back to the same vertex
Loop - vertex has an edge to itself
*/

class Graph
{
public:
	struct Vertex;//Graph::Vertex

	struct Edge
	{	
		//struct Vertex;//Graph::Edge::Vertex (Different struct)
		double weight;
		Vertex* neighbor;
		Edge(Vertex* v, double w = 1)
		{
			neighbor = v;
			weight = w;
		}
	};

	struct Vertex
	{
		vector<Edge> edges;
		Vertex* visitingVertex;
		int num;//ID to tell each vertex apart
		bool visited;

		Vertex(int n)
		{
			num = n;
			visited = false;
		}
		
		void AddNeighbor(Vertex* v)
		{
			edges.push_back(Edge(v));
			v->edges.push_back(Edge(this));
		}

		//Position pos;
		//string cityName;
	};
	
	vector<Vertex> vertices;

	void AddVertex(int n)
	{
		vertices.push_back(Vertex(n));
	}

	Vertex* operator[] (int index)
	{
		return &vertices[index];
	}

	void PrintGraph()
	{
		for (int i = 0; i < vertices.size(); i++)
		{
			if (vertices[i].edges.size() > 0)
			{
				cout << "Vertex " << vertices[i].num << " is connected to vertices: " << endl;
				for (int j = 0; j < vertices[i].edges.size(); j++)
					cout << "\t" << vertices[i].edges[j].neighbor->num << " with weight " << vertices[i].edges[j].weight << endl;
			}
			else
				cout << "Vertex " << vertices[i].num << " has no neighbors. :(" << endl;
		}
	}

	void PrintPath(Vertex* start, Vertex* end)
	{
		//start at end vertex and go through visiting vertex until reach start
		Vertex* temp = end;
		stack<Vertex*> stack; 

		while (temp != start)
		{
			stack.push(temp);
			temp = temp->visitingVertex;

		}
		if (temp == start)
		{
			stack.push(temp);
		}

		cout << "Path: ";
		while (stack.size()-1 != 0)
		{
			cout << stack.top()->num << " -> ";
			stack.pop();
		}
		if (stack.size() == 1)
			cout << stack.top()->num << endl;
		return;
	}

	void BreadthFirstSearch(Vertex* start, int n)
	{
		for (int i = 0; i < vertices.size(); i++)
			vertices[i].visited = false;

		for (int i = 0; i < vertices.size(); i++)
			vertices[i].visitingVertex = nullptr;
		queue<Vertex*> nodes;
		nodes.push(start);
		Vertex* temp = start;
		int numChecked = 0;

		while (temp->num != n && nodes.size() > 0)
		{

			temp = nodes.front();
			nodes.pop();

			if (!temp->visited)
			{
				numChecked++;
				temp->visited = true;

				cout << "Checking Vertex " << temp->num << endl;

				for (int i = 0; i < temp->edges.size(); i++)
					if (!temp->edges[i].neighbor->visited)
					{
						nodes.push(temp->edges[i].neighbor);
						temp->edges[i].neighbor->visitingVertex = temp;
					}
			}
		}

		if (temp->num == n)
		{
			cout << "Found Vertex " << n << " after checking " << numChecked << " vertices " << endl;
			PrintPath(start, temp);
		}
		else
			cout << "Couldn't find Vertex " << n << " after checking " << numChecked << " vertices " << endl;
	}

	void DepthFirstSearch(Vertex* start, int n)
	{
		for (int i = 0; i < vertices.size(); i++)
			vertices[i].visited = false;

		for (int i = 0; i < vertices.size(); i++)
			vertices[i].visitingVertex = nullptr;
		stack<Vertex*> nodes;
		nodes.push(start);
		Vertex* temp = start;
		Vertex* temp2 = temp;
		int numChecked = 0;

		while (temp->num != n && nodes.size() > 0)
		{
			temp = nodes.top();
			nodes.pop();

			if (!temp->visited)
			{
				numChecked++;
				temp->visited = true;

				cout << "Checking Vertex " << temp->num << endl;

				for (int i = 0; i < temp->edges.size(); i++)
					if (!temp->edges[i].neighbor->visited)
					{
						nodes.push(temp->edges[i].neighbor);
						temp->edges[i].neighbor->visitingVertex = temp;
					}
			}
		}

		if (temp->num == n)
		{
			cout << "Found Vertex " << n << " after checking " << numChecked << " vertices " << endl;
			PrintPath(start, temp);
		}
		else
			cout << "Couldn't find Vertex " << n << " after checking " << numChecked << " vertices " << endl;
	}
};