#include <iostream>

#include "Graph.h"

using namespace std;

int main()
{
	Graph graph;

	for (int i = 0; i < 10; i++)
		graph.AddVertex(i);

	//graph.vertices[0].AddNeighbor(&graph.vertices[1]);
	graph[0]->AddNeighbor(graph[1]);
	graph[0]->AddNeighbor(graph[3]);
	graph[1]->AddNeighbor(graph[4]);
	graph[3]->AddNeighbor(graph[2]);
	graph[3]->AddNeighbor(graph[6]);
	graph[6]->AddNeighbor(graph[4]);
	graph[6]->AddNeighbor(graph[9]);
	graph[4]->AddNeighbor(graph[7]);
	graph[4]->AddNeighbor(graph[5]);
	graph[2]->AddNeighbor(graph[5]);
	graph[7]->AddNeighbor(graph[8]);
	graph[5]->AddNeighbor(graph[8]);

	graph.PrintGraph();

	graph.BreadthFirstSearch(graph[0], 8);
	graph.DepthFirstSearch(graph[0], 8);

	return 0;
}