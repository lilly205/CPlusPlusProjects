#ifndef CARDS_H
#define CARDS_H

#include <iostream>

using namespace std;

#include <string>

class Cards
{
public:
	Cards(string cardName, int cardValue, int cardID)
	{
		this->cardName = cardName;
		this->cardValue = cardValue;
		this->cardID = cardID;
	}
	void ShowCardName()
	{
		cout << cardName << endl;
		return;
	}
	int CardValue()
	{
		return cardValue;
	}
private:
	string cardName;
	int cardValue;
	int cardID;

};


#endif CARDS_H