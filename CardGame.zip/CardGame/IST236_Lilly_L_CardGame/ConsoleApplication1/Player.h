#ifndef PLAYER_H
#define PLAYER_H
#include <stack>
#include <iostream>
#include "Card.h"
#include <string>

using namespace std;

class Player
{

public:
	virtual void TakeTurn() = 0
	{
		deck.top()->ShowCardName();
		deck.pop();
		return;
	}
	void AssignDeck(vector<Cards*> deckVector)
	{
		for (int i = 0; i < 26; i++)
		{
			deck.push(deckVector[i]);
		}
	}
	void Win()
	{
		winCount++;
		return;
	}
	Cards* Discard() const
	{
		return deck.top();
	}
	void Pop()
	{
		deck.pop();
		return;
	}
	int CardValue() const
	{
		return deck.top()->CardValue();
	}
	bool isEmpty() const
	{
		if (deck.size() == 0)
		{
			return true;
		}
		else 
			return false;
	}
protected:
	stack <Cards*> deck;
	int winCount;
};

class HumanPlayer : public Player
{
public:
	void TakeTurn() override
	{
		cout << "Play card? (Press any key and enter to continue) ";
				cin >> input;
				cout << "You play: ";
				deck.top()->ShowCardName();
					
		return;
	}

private:
	string input;
};

class AIPlayer : public Player
{
public:
	void TakeTurn() override
	{
		cout << "Opponent plays: ";
		deck.top()->ShowCardName();
		return;
	}
};


#endif