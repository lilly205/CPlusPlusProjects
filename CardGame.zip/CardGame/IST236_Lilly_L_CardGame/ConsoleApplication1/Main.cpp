/*
Final Project
By: Levi Lilly
Date: 12/8/2015
*/
#include <iostream>
#include <vector>
#include <string>
#include <algorithm>
#include <stack>
#include "Card.h"
#include <queue>
#include "Player.h"
#include <ctime>        
#include <cstdlib> 
#include "MemLeakDetector.h"


using namespace std;
int myrandom(int i) { return std::rand() % i; }
int main()
{
	std::srand(unsigned(std::time(0))); // random shuffle code

	vector <Cards*> deckVector;


	Cards Spade2("Two of Spades", 2, 1);
	deckVector.push_back(new Cards(Spade2));
	Cards Spade3("Three of Spades", 3, 2);
	deckVector.push_back(new Cards(Spade3));
	Cards Spade4("Four of Spades", 4, 3);
	deckVector.push_back(new Cards(Spade4));
	Cards Spade5("Five of Spades", 5, 4);
	deckVector.push_back(new Cards(Spade5));
	Cards Spade6("Six of Spades", 6, 5);
	deckVector.push_back(new Cards(Spade6));
	Cards Spade7("Seven of Spades", 7, 6);
	deckVector.push_back(new Cards(Spade7));
	Cards Spade8("Eight of Spades", 8, 7);
	deckVector.push_back(new Cards(Spade8));
	Cards Spade9("Nine of Spades", 9, 8);
	deckVector.push_back(new Cards(Spade9));
	Cards Spade10("Ten of Spades", 10, 9);
	deckVector.push_back(new Cards(Spade10));
	Cards SpadeJ("Jack of Spades", 11, 10);
	deckVector.push_back(new Cards(SpadeJ));
	Cards SpadeQ("Queen of Spades", 12, 11);
	deckVector.push_back(new Cards(SpadeQ));
	Cards SpadeK("King of Spades", 13, 12);
	deckVector.push_back(new Cards(SpadeK));
	Cards SpadeA("Ace of Spades", 14, 13);
	deckVector.push_back(new Cards(SpadeA));

	Cards Diamond2("Two of Diamonds", 2, 14);
	deckVector.push_back(new Cards(Diamond2));
	Cards Diamond3("Three of Diamonds", 3, 15);
	deckVector.push_back(new Cards(Diamond3));
	Cards Diamond4("Four of Diamonds", 4, 16);
	deckVector.push_back(new Cards(Diamond4));
	Cards Diamond5("Five of Diamonds", 5, 17);
	deckVector.push_back(new Cards(Diamond5));
	Cards Diamond6("Six of Diamonds", 6, 18);
	deckVector.push_back(new Cards(Diamond6));
	Cards Diamond7("Seven of Diamonds", 7, 19);
	deckVector.push_back(new Cards(Diamond7));
	Cards Diamond8("Eight of Diamonds", 8, 20);
	deckVector.push_back(new Cards(Diamond8));
	Cards Diamond9("Nine of Diamods", 9, 21);
	deckVector.push_back(new Cards(Diamond9));
	Cards Diamond10("Ten of Diamonds", 10, 22);
	deckVector.push_back(new Cards(Diamond10));
	Cards DiamondJ("Jack of Diamonds", 11, 23);
	deckVector.push_back(new Cards(DiamondJ));
	Cards DiamondQ("Queen of Diamonds", 12, 24);
	deckVector.push_back(new Cards(DiamondQ));
	Cards DiamondK("King of Diamonds", 13, 25);
	deckVector.push_back(new Cards(DiamondK));
	Cards DiamondA("Ace of Diamonds", 14, 26);
	deckVector.push_back(new Cards(DiamondA));

	Cards Club2("Two of Clubs", 2, 27);
	deckVector.push_back(new Cards(Club2));
	Cards Club3("Three of Clubs", 3, 28);
	deckVector.push_back(new Cards(Club3));
	Cards Club4("Four of Clubs", 4, 29);
	deckVector.push_back(new Cards(Club4));
	Cards Club5("Five of Clubs", 5, 30);
	deckVector.push_back(new Cards(Club5));
	Cards Club6("Six of Clubs", 6, 31);
	deckVector.push_back(new Cards(Club6));
	Cards Club7("Seven of Clubs", 7, 32);
	deckVector.push_back(new Cards(Club7));
	Cards Club8("Eight of Clubs", 8, 33);
	deckVector.push_back(new Cards(Club8));
	Cards Club9("Nine of Clubs", 9, 34);
	deckVector.push_back(new Cards(Club9));
	Cards Club10("Ten of Clubs", 10, 35);
	deckVector.push_back(new Cards(Club10));
	Cards ClubJ("Jack of Clubs", 11, 36);
	deckVector.push_back(new Cards(ClubJ));
	Cards ClubQ("Queen of Clubs", 12, 37);
	deckVector.push_back(new Cards(ClubQ));
	Cards ClubK("King of Clubs", 13, 38);
	deckVector.push_back(new Cards(ClubK));
	Cards ClubA("Ace of Clubs", 14, 39);
	deckVector.push_back(new Cards(ClubA));

	Cards Heart2("Two of Hearts", 2, 40);
	deckVector.push_back(new Cards(Heart2));
	Cards Heart3("Three of Hearts", 3, 41);
	deckVector.push_back(new Cards(Heart3));
	Cards Heart4("Four of Hearts", 4, 42);
	deckVector.push_back(new Cards(Heart4));
	Cards Heart5("Five of Hearts", 5, 43);
	deckVector.push_back(new Cards(Heart5));
	Cards Heart6("Six of Hearts", 6, 44);
	deckVector.push_back(new Cards(Heart6));
	Cards Heart7("Seven of Hearts", 7, 45);
	deckVector.push_back(new Cards(Heart7));
	Cards Heart8("Eight of Hearts", 8, 46);
	deckVector.push_back(new Cards(Heart8));
	Cards Heart9("Nine of Hearts", 9, 47);
	deckVector.push_back(new Cards(Heart9));
	Cards Heart10("Ten of Hearts", 10, 48);
	deckVector.push_back(new Cards(Heart10));
	Cards HeartJ("Jack of Hearts", 11, 49);
	deckVector.push_back(new Cards(HeartJ));
	Cards HeartQ("Queen of Hearts", 12, 50);
	deckVector.push_back(new Cards(HeartQ));
	Cards HeartK("King of Hearts", 13, 51);
	deckVector.push_back(new Cards(HeartK));
	Cards HeartA("Ace of Hearts", 14, 52);
	deckVector.push_back(new Cards(HeartA)); // All of the cards


	cout << "Welcome to: LUCKY SEVENS! First player to draw a Seven of any kind wins " << endl;
	cout << "the round! First player to win a round 3 times wins the game!" << endl;

	random_shuffle(deckVector.begin(), deckVector.end(), myrandom); // random shuffle


	queue <Player*> PlayerQueue;
	stack <Cards*> DiscardPile;
	vector<Cards*> playerDeck;
	for (int i = 0; i < 26; i++)
	{
		playerDeck.push_back(deckVector[i]);
	}
	vector<Cards*> aiDeck;
	for (int i = 0; i < 26; i++)
	{
		aiDeck.push_back(deckVector[i + 26]);
	}

	HumanPlayer player;
	AIPlayer aiPlayer;
	player.isEmpty();
	aiPlayer.isEmpty();
	player.AssignDeck(playerDeck);
	aiPlayer.AssignDeck(aiDeck);
	player.isEmpty();
	aiPlayer.isEmpty();
	PlayerQueue.push(&player);
	PlayerQueue.push(&aiPlayer);
	int playerWin = 0;
	int aiWin = 0;		
	while ((playerWin < 3) && (aiWin < 3)){ // as long as the player and ai dont have above three wins, the game will continue
		if ((playerWin > 0) || (aiWin > 0)) //reshuffles the cards after a win
		{while (player.isEmpty() != true)	//should take all remaining cards and discard them
			{
				DiscardPile.push(player.Discard());
				player.Pop();
			}
			while (aiPlayer.isEmpty() != true)
			{
				DiscardPile.push(aiPlayer.Discard());
				aiPlayer.Pop();
			}
			cout << "Reshuffling! AI Wins: " << aiWin << " Player Wins: " << playerWin << endl;
			cout << endl;
			deckVector.erase (deckVector.begin(),deckVector.end()); // erases original deckVector and will replace vector with the discard pile
			for(int i = 0; i < 52; i++)
			{
				deckVector.push_back(DiscardPile.top());
				DiscardPile.pop();
			}
			random_shuffle(deckVector.begin(), deckVector.end(), myrandom); // shuffles the vector
			playerDeck.erase (playerDeck.begin(),playerDeck.end()); // erases player and ai decks. Then readds cards to their decks
			aiDeck.erase (aiDeck.begin(),aiDeck.end());
			for (int i = 0; i < 26; i++)
			{
				playerDeck.push_back(deckVector[i]);
			}
			for (int i = 0; i < 26; i++)
			{
				aiDeck.push_back(deckVector[i + 26]);
			}
			
			player.AssignDeck(playerDeck); // assigns each deck
			aiPlayer.AssignDeck(aiDeck);
			
			while (DiscardPile.size() != 0) // resets discard pile
			{
				DiscardPile.pop();
			}
		}
	for (int i = 0; i < 26; i++)
	{
		int playerVal;
		int aiVal;
		PlayerQueue.front()->TakeTurn();
		DiscardPile.push(PlayerQueue.front()->Discard());
		playerVal = PlayerQueue.front()->CardValue();
		PlayerQueue.front()->Pop();
		PlayerQueue.push(PlayerQueue.front());
		PlayerQueue.pop();
		PlayerQueue.front()->TakeTurn();
		DiscardPile.push(PlayerQueue.front()->Discard());
		aiVal = PlayerQueue.front()->CardValue();
		PlayerQueue.front()->Pop();
		PlayerQueue.push(PlayerQueue.front());
		PlayerQueue.pop();
		if (aiVal == 7 && playerVal == 7)
		{
			cout << "Tie!" << endl;
			
			break;
		}
		else if (aiVal == 7){ 
			cout << "AI wins the round!" << endl;
			aiWin++;
			break;
		}
		else if (playerVal == 7){
			cout << "You won the round!" << endl;
			playerWin++;
			break;
		}
	}
	}
		if (aiWin == 3) {
			cout << "AI wins the game! Thank you for playing!" << endl;
		}
		else if (playerWin == 3) {
			cout << "You win the game! Thank you for playing!" << endl;
		}
	

	for (int i = 0; i << deckVector.size(); i++)
		delete deckVector[i];
	deckVector.clear();



	return 0;
}