#ifndef MEMLEAKDETECTOR_H
#define MEMLEAKDETECTOR_H

#define _CRTDBG_MAP_ALLOC
#include <stdlib.h>
#include <crtdbg.h>

#ifndef DBG_NEW
#define DBG_NEW new (_NORMAL_BLOCK, __FILE__, __LINE__)
#define new DBG_NEW
#endif

//Detects memory leaks. You only need to include the file for it to work; you do not need to instantiate any MemLeakDetector objects.
class MemLeakDetector
{
public:
	~MemLeakDetector()
	{
		_CrtDumpMemoryLeaks();
	}
};

 //When the program exits, this object will be destroyed, which will invoke its destructor, which calls the system function that detects memory leaks.
MemLeakDetector memLeakDetector;

#endif