#include <iostream>
#include <random>
#include <time.h>
#include "Timer.h"

using namespace std;

template <class T>
static void FastMergeSort(vector<T> &vec, int left, int right, vector<T> &leftArray, vector<T> &rightArray)
{
	if (left < right)
	{
		int mid = (left + right) / 2;
		if ((mid + 1) - left > 10)
		{
			FastMergeSort(vec, left, mid, leftArray, rightArray);
		}
		else
		{
			InsertionSortMerge(vec, left, mid);
		}

		if (right - mid > 10)
		{
			FastMergeSort(vec, mid + 1, right, leftArray, rightArray);
		}
		else
		{
			InsertionSortMerge(vec, mid + 1, right);
		}

		FastMerge(vec, left, mid, right, leftArray, rightArray);
	}
}

template <class T>
static void FastMerge(vector<T> &vec, int left, int mid, int right, vector<T> &leftArray, vector<T> &rightArray)
{
	int leftArraySize = mid - left + 1;//n1 in the pseudocode
	int rightArraySize = right - mid;//n2



	for (int i = 0; i < leftArraySize; i++)
		leftArray[i] = vec[left + i];

	for (int i = 0; i < rightArraySize; i++)
		rightArray[i] = vec[mid + i + 1];

	leftArray[leftArraySize] = INT_MAX;
	rightArray[rightArraySize] = INT_MAX;


	int i = 0, j = 0;
	for (int k = left; k <= right; k++)
	{
		if (leftArray[i] <= rightArray[j])
			vec[k] = leftArray[i++];
		else
			vec[k] = rightArray[j++];
	}
}

template <class T>
static void InsertionSortMerge(vector<T> &vec, int left, int right)
{
	for (int j = left + 1; j < right + 1; j++)
	{
		T key = vec[j];
		int i = j - 1;
		while (i >= left && vec[i] > key)
		{
			vec[i + 1] = vec[i];
			i--;
		}
		vec[i + 1] = key;
	}
}

template <class T>
static void MergeSort(vector<T> &vec, int left, int right)
{
	if (left < right)
	{
		int mid = (left + right) / 2;
		MergeSort(vec, left, mid);
		MergeSort(vec, mid + 1, right);
		Merge(vec, left, mid, right);
	}
}

template <class T>
static void Merge(vector<T> &vec, int left, int mid, int right)
{
	int leftArraySize = mid - left + 1;//n1 in the pseudocode
	int rightArraySize = right - mid;//n2

	vector<T> leftArray;
	vector<T> rightArray;

	for (int i = 0; i < leftArraySize; i++)
		leftArray.push_back(vec[left + i]);

	for (int i = 0; i < rightArraySize; i++)
		rightArray.push_back(vec[mid + i + 1]);

	leftArray.push_back(INT_MAX);
	rightArray.push_back(INT_MAX);

	int i = 0, j = 0;
	for (int k = left; k <= right; k++)
	{
		if (leftArray[i] <= rightArray[j])
			vec[k] = leftArray[i++];
		else
			vec[k] = rightArray[j++];
	}
}

struct SubarrayResult
{
	int leftIndex, rightIndex, sum;

	SubarrayResult(int l, int r, int s)
	{
		leftIndex = l;
		rightIndex = r;
		sum = s;
	}
};


SubarrayResult FindMaxCrossingSubarray(int arr[], int leftIndex, int mid, int rightIndex)
{
	int leftSum = INT_MIN;
	int sum = 0;
	int maxLeft = leftIndex;
	for (int i = mid; i > leftIndex; i--)
	{
		sum += arr[i];
		if (sum > leftSum)
		{
			leftSum = sum;
			maxLeft = i;
		}
	}
	int rightSum = INT_MIN;
	sum = 0;
	int maxRight = rightIndex;
	for (int j = mid + 1; j < rightIndex; j++)
	{
		sum += arr[j];
		if (sum > rightSum)
		{
			rightSum = sum;
			maxRight = j;
		}
	}
	return SubarrayResult(maxLeft, maxRight, leftSum + rightSum);
}

SubarrayResult FindMaxSubarray(int arr[], int leftIndex, int rightIndex)
{
	if (rightIndex == leftIndex)
	{
		return SubarrayResult(leftIndex, rightIndex, arr[leftIndex]);
	}
	else
	{
		int mid = ((leftIndex + rightIndex) / 2);
		
		SubarrayResult l = FindMaxSubarray(arr, leftIndex, mid);
		SubarrayResult r = FindMaxSubarray(arr, mid + 1, rightIndex);
		SubarrayResult c = FindMaxCrossingSubarray(arr, leftIndex, mid, rightIndex);
		if (l.sum >= r.sum && l.sum >= c.sum)
		 {
			return SubarrayResult(l.leftIndex, l.rightIndex, l.sum);
		 }
		else if (r.sum >= l.sum && r.sum >= c.sum)
		{
			return SubarrayResult(r.leftIndex, r.rightIndex, r.sum);
		}
		else
		{
			return SubarrayResult(c.leftIndex, c.rightIndex, c.sum);
		}
	}
}



template <class T>
static void InsertionSort(vector<T> &vec, int size)
{
	for (int j = 1; j < size; j++)
	{
		T key = vec[j];
		int i = j - 1;
		while (i >= 0 && vec[i] > key)
		{
			vec[i + 1] = vec[i];
			i--;
		}
		vec[i + 1] = key;
	}
}

template <class T>
void Swap(T &x, T &y)
{
	T temp = x;
	x = y;
	y = temp;
}

template <class T>
void selectionSort(T arr[], int size) // slow but used from class
{

	for (int j = 0; j < size; j++)
	{
		int smallestIndex = j;
		for (int i = j; i < size; i++)
		{
			if (arr[i] < arr[smallestIndex])
				smallestIndex = i;
		}
		Swap(arr[j], arr[smallestIndex]);

	}

}

template <class T>
T unsortedThirdLargest(T arr[], int size) // will really only work with at least 3 elements
{
	T thirdLargest = arr[0];		// keeps track of third, second, and greatest values
	T secondLargest = arr[0];
	T largest = arr[0];
	for (int i = 0; i < size; i++)
	{
		if (thirdLargest < arr[i] && arr[i] != secondLargest && arr[i] != largest) // checks if the value at i is greater than third largest and checks to prevents duplicates
		{
			if (secondLargest < arr[i] && arr[i] != largest)	// then checks if i is greater than the second largest and prevents duplicates
			{
				if (largest < arr[i]) // if i is greater than largest then third value to second, second to first, first to i
				{
					thirdLargest = secondLargest;
					secondLargest = largest;
					largest = arr[i];
				}
				else // if i is less than largest and greater than second then set third value to second and second value to i
				{
					thirdLargest = secondLargest;
					secondLargest = arr[i];
				}
			}
			else // if i is less than second but greater than third then set third to i
			{
				thirdLargest = arr[i];
			}

		}
	}
	return thirdLargest;
}

template <class T>
T sortestThirdLargest(T arr[], int size)
{
	selectionSort(arr, size); // sort array

	int count = 0; // keeps track of how many jumps between non duplicate numbers there are (2 jumps = third largest)
	int temp = arr[size - 1]; // temp value used to compare i and the last element compared. Used for checking duplicates
	for (int i = size - 1; ((i--) > 0);) // loops backwards until i is 0
	{
		if (temp != arr[i]) // if the last non duplicate value checked is not a duplicate then add to count and set the temp to the new value
		{
			count++;
			temp = arr[i];
		}
		if (count == 2) // once count is 2 return the value (third largest)
		{
			return arr[i];
		}
	}
	return arr[0]; // if it doesnt ever reach 2 jumps then the first value in array should be the lowest if sorted.
}


int main()
{
	srand(time(NULL));
	int arr[10];
	for (int i =0; i < 10; i++)
	{
		arr[i] = rand() % 20 - 10;
	}

	for (int i = 0; i < 10; i++)
	{
		cout << arr[i] << " ";
	}

	//int arr[] = { -2,-5,6,-2,-3,1,5,-6 }; used to test

	SubarrayResult s(0, 0, 0);
	s = FindMaxSubarray(arr, 0, 9);
	cout << "Left Index: " << s.leftIndex << " Right Index: " << s.rightIndex << " Sum: " << s.sum << endl;

	vector<int> intVec;
	int n = 10;
	Timer timer;
	
#pragma region SHOULD PUT IN A FUNCTION
	intVec.resize(n);
	for (unsigned int i = 0; i < n; i++)
	{
		//intVec.push_back(rand() % n);
		intVec[i] = rand() % n;
	}
	vector<int> leftArray;
	leftArray.resize((n/2)+1);
	vector<int> rightArray;
	rightArray.resize((n/2)+1);
	timer.Start();
	FastMergeSort(intVec, 0, intVec.size() - 1, leftArray, rightArray);
	timer.Stop();
	cout << "Fast Merge For " << n << " Ints: " << timer.GetMillisecondsElapsed() << "ms" << endl;
	timer.Reset();
	timer.Start();
	MergeSort(intVec, 0, intVec.size() - 1);
	timer.Stop();
	cout << "Merge For " << n << " Ints: " << timer.GetMillisecondsElapsed() << "ms" << endl;
	timer.Reset();

	n = 1000;
	intVec.resize(n);
	for (unsigned int i = 0; i < n; i++)
	{
		//intVec.push_back(rand() % n);
		intVec[i] = rand() % n;
	}
	leftArray.resize((n / 2) + 1);
	rightArray.resize((n / 2) + 1);
	timer.Start();
	FastMergeSort(intVec, 0, intVec.size() - 1, leftArray, rightArray);
	timer.Stop();
	cout << "Fast Merge For " << n << " Ints: " << timer.GetMillisecondsElapsed() << "ms" << endl;
	timer.Reset();
	timer.Start();
	MergeSort(intVec, 0, intVec.size() - 1);
	timer.Stop();
	cout << "Merge For " << n << " Ints: " << timer.GetMillisecondsElapsed() << "ms" << endl;
	timer.Reset();

	n = 100000;
	intVec.resize(n);
	for (unsigned int i = 0; i < n; i++)
	{
		//intVec.push_back(rand() % n);
		intVec[i] = rand() % n;
	}
	leftArray.resize((n / 2) + 1);
	rightArray.resize((n / 2) + 1);
	timer.Start();
	FastMergeSort(intVec, 0, intVec.size() - 1, leftArray, rightArray);
	timer.Stop();
	cout << "Fast Merge For " << n << " Ints: " << timer.GetMillisecondsElapsed() << "ms" << endl;
	timer.Reset();
	timer.Start();
	MergeSort(intVec, 0, intVec.size() - 1);
	timer.Stop();
	cout << "Merge For " << n << " Ints: " << timer.GetMillisecondsElapsed() << "ms" << endl;
	timer.Reset();
#pragma endregion


	return 0;
}