#include <windows.h>

#include "Timer.h"

Timer::Timer()
{
	startTime = 0;
	timePassed = 0;

	//This sets our secondsPerCount and mSecondsPerCount variables  
	//so that we can convert from Tics to seconds or milliseconds 

	long long countsPerSec;
	QueryPerformanceFrequency((LARGE_INTEGER*)&countsPerSec);
	secondsPerCount = 1.0 / (double)countsPerSec;
	mSecondsPerCount = secondsPerCount * 1000;
}

void Timer::Start()
{
	//This just sets startTime to the current time

	QueryPerformanceCounter((LARGE_INTEGER*)&startTime);
}

void Timer::Stop()
{
	//This sets currTime to the current time, then subtracts startTime 
	//from currTime to get the elapsed time since Start() was called.

	long long currTime;
	QueryPerformanceCounter((LARGE_INTEGER*)&currTime);
	timePassed += currTime - startTime;
}

void Timer::Reset()
{
	//This sets timePassed back to 0 assuming Start() and Stop() 
	//have been called to record some amount of elapsed time

	timePassed = 0;
}

long long Timer::GetTicsElapsed()
{
	return timePassed;
}

double Timer::GetSecondsElapsed()
{
	return timePassed * secondsPerCount;
}

double Timer::GetMillisecondsElapsed()
{
	return timePassed * mSecondsPerCount;
}