#ifndef HIGHPRECISIONTIMER_H
#define HIGHPRECISIONTIMER_H

///A high precision timer class.
class Timer
{
public:
	//Constructor
	Timer();

	//Start timing, or resume if Stop() was called before Reset()
	void Start();

	//Stop timing. Does not reset.
	void Stop();

	//Reset the timer
	void Reset();

	//Return how many tics (CPU clock cycles) have passed
	long long GetTicsElapsed();

	//Return how many seconds have passed
	double GetSecondsElapsed();

	//Return how many millieseconds have passed
	double GetMillisecondsElapsed();

private:
	long long startTime;
	long long timePassed;
	double secondsPerCount;
	double mSecondsPerCount;
};

#endif